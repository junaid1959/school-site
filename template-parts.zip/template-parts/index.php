<?php
/**
 * The main template file

 */

get_header(); ?>


	<div id="primary" class="content-area">
		<main id="main" class="wrapper" role="main">

            <!-- start home page content-->
        <div id="main-banner">
        <img src="<?php echo(get_template_directory_uri());?>/images/banner.jpg" alt="welcome to our site">
            </div>
        
        <div class="wrapper">
        <section id="home-menu">
        <h1>MENU</h1>
          <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul>  
            
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            <ul>
            <li>
              <span class="dish">falluda</span>
                <span class="price">50$</span>
                <span class="discription">world delishes falluda you ill get hear</span>
              </li>
            </ul> 
            </section>
        
        <section class="featured">
        <ul>
            <li><img src="<?php echo(get_template_directory_uri());?>/images/03.jpg">
            <a href="">chicken tikka</a>
                <span>$60</span>
                <span class="rating"></span>
            </li>
            
            <li><img src="<?php echo(get_template_directory_uri());?>/images/04.jpg">
            <a href="">chicken tikka</a>
                <span>$60</span>
                <span class="rating"></span>
            </li>
            
            <li><img src="<?php echo(get_template_directory_uri());?>/images/03.jpg">
            <a href="">chicken tikka</a>
                <span>$60</span>
                <span class="rating"></span>
            </li>
            
            <li><img src="<?php echo(get_template_directory_uri());?>/images/04.jpg">
            <a href="">chicken tikka</a>
                <span>$60</span>
                <span class="rating"></span>
            </li>
            
            </ul>
        
        </section>
            </div>
        <!-- close home page content-->
            
            
            
		</main><!-- .site-main -->
	</div><!-- .content-area -->


<?php get_footer(); ?>

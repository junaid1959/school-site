<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		
            
        <div class="wrapper" id="page-content">
            <?php while(have_post())  : the_post(); ?>
            <?php get_template_part( 'content', 'page' ); ?>	
            <?php endwhile; ?>
            
            </div>
             </main><!-- .site-main -->
	</div><!-- .content-area -->


<?php get_footer(); ?>


	</main><!-- .site-main -->



</div><!-- .content-area -->


<?php get_footer(); ?>

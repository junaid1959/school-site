<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *

 */
?>

		</div><!-- .site-content -->

		<footer>
            
            
            <ul>
            <li>a cpmplete care restorent</li>
                <li>karnataka-bangalore</li>
                <li>mob: 8050321398</li>
                  </ul>
             <ul>
            <li>a complete care restorent</li>
                <li>karnataka-bangalore</li>
                <li>mob: 8050321398</li>
                  </ul>
             <ul>
            <li><a href="">career</a></li>
                <li><a href="">blog</a></li>
                <li><a href="">pravice police</a> </li>
                  <li><a href="">contact</a></li>
                  </ul>
            <ul>
            <li><img src="<?php echo(get_template_directory_uri()); ?>/images/LOGO1.png" alt="logo"> </li>
                <li> designed By Syed Junaid</li>
                <li>&copy; All rights reserved2018</li>
                <li>find more @ <a href="http://www.beautybuddys.ml/">Beauty-buddys</a>   </li>
            </ul>
			
		</footer><!-- .site-footer -->
	</div><!-- .site-inner -->
</div><!-- .site -->

<?php wp_footer(); ?>
</body>
</html>

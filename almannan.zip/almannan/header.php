<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package SKT IT Consultant
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>


<body <?php body_class(); ?>>
    <div class="wrapper_main">   
        <header class="header">
        	<div class="container">
                <div class="head_fix">
                 <div id="logo">
                 	<div id="header-image">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
       <img src="<?php echo get_template_directory_uri(); ?>/images/slides/almannan-logo.png" alt="Logo" width="HERE" height="HERE" />
    </a>
</div>
                </div>
                <div class="header_right">
		
		  <h4 class="phone"><span><?php _e('Call Us:','itconsultant'); ?></span> <?php echo get_theme_mod('contact_call', '+91 08214289922,4266611'); ?></h4></br >
			
                   <div class="mobile_nav"><a href="#"><?php _e('Menu...','itconsultant'); ?></a></div>
                <nav id="nav">
                  <?php wp_nav_menu( array('theme_location'  => 'primary', 'container' => '', 'container_class' => '', 'items_wrap' => '<ul>%3$s</ul>' ) ); ?>
                 </nav>                     
                </div>
	            <div class="clear"></div> 
                </div><!--end.head_fix-->                           
            </div>             
        </header>
